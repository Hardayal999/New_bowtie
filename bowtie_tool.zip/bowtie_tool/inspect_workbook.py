"""
inspect_workbook.py  -  run this FIRST on a hazard log you have not used before.

    python inspect_workbook.py "Other project.xlsx"

It lists every sheet and its column headings, and writes its best guess at the
mapping to "mapping_suggested.xlsx". The guess is made from the WORDING of the
headings only, so A PERSON MUST CHECK EVERY YELLOW CELL before it is used.
Then run
    python build_bowties.py "Other project.xlsx" --mapping mapping_suggested.xlsx

Nothing in the hazard log is changed.
"""

import sys
import warnings

import openpyxl

from bowtie.mapping import SETTINGS, write_mapping
from bowtie.workbook import clean, loose

# Words that suggest what a heading means. For each setting, earlier words are stronger hints.
HINTS = {
    "Register sheet": {
        "top_event": ["top event", "loss of control", "hazardous event", "hazards", "hazard"],
        "hazard": ["context", "activity", "hazard category"],
        "cause": ["causes", "cause", "threats", "threat"],
        "consequence": ["consequences", "consequence", "outcome"],
        "control": ["controls", "control", "barriers", "barrier", "safeguard"],
        "control_type": ["control type", "type of control", "barrier type"],
        "control_hierarchy": ["control hierarchy", "hierarchy"],
        "control_owner": ["control owner allocation", "control owner", "owner"],
        "control_status": ["control status", "status"],
        "initial_likelihood": ["initial likelihood", "inherent likelihood"],
        "initial_consequence": ["initial consequences", "initial consequence", "inherent consequence"],
        "initial_rating": ["initial rating", "inherent rating", "initial risk", "inherent risk"],
        "residual_likelihood": ["residual likelihood"],
        "residual_consequence": ["residual consequences", "residual consequence"],
        "residual_rating": ["residual rating", "residual risk"],
        "work_package": ["works package allocation", "work package allocation", "works package", "work package"],
        "life_cycle": ["design life cycle stage", "project life cycle", "life cycle", "lifecycle"],
        "guideword": ["guideword", "guidewords"],
    },
    "Hazards tab": {"id": ["hazard id", "hazard ref", "top event id"], "name": ["hazard", "top event"],
                    "hazard": ["context", "activity", "category"]},
    "Causes tab": {"id": ["cause id", "cause ref", "threat id"], "name": ["cause", "threat"],
                   "top_event_ids": ["hazard id", "hazard ids", "top event id"],
                   "consequence_ids": ["consequence id", "consequence ids"],
                   "initial_rating": ["initial rating", "inherent rating"], "residual_rating": ["residual rating"],
                   "work_package": ["works package allocation", "work package allocation", "work package"],
                   "life_cycle": ["design life cycle stage", "project life cycle", "life cycle"],
                   "guideword": ["guideword", "guidewords"]},
    "Controls tab": {"id": ["control id", "barrier id"], "name": ["control measure", "control", "barrier"],
                     "type": ["control type"], "hierarchy": ["control hierarchy", "hierarchy"],
                     "owner": ["control owner allocation", "control owner", "owner"],
                     "status": ["control status", "status"], "cause_ids": ["cause id", "cause ids"]},
    "Consequences tab": {"id": ["consequence id"], "name": ["consequences", "consequence"]},
}
TITLE_WORDS = {"Hazards tab": "hazard", "Causes tab": "cause", "Controls tab": "control",
               "Consequences tab": "consequence"}


def headings_of(sheet):
    """Guess the header row: the row in the first 40 with the most text cells."""
    best = []
    for row in sheet.iter_rows(min_row=1, max_row=40, values_only=True):
        texts = [clean(cell) for cell in row if isinstance(cell, str) and clean(cell)]
        if len(texts) > len(best):
            best = texts
    return best


def guess_columns(headings, hints):
    """
    For one sheet, pick a heading for each setting. Returns {setting: (heading, how it was guessed)}.
    A heading that matches a hint word exactly is preferred to one that merely contains it,
    and a heading is never used for two settings.
    """
    found, used = {}, set()
    for exact in (True, False):
        for setting, words in hints.items():
            if setting in found:
                continue
            for word in words:
                matches = [h for h in headings if h not in used and
                           (loose(h) == word if exact else word in loose(h))]
                if matches:
                    found[setting] = (matches[0], "heading matches exactly" if exact
                                      else f'heading contains "{word}"')
                    used.add(matches[0])
                    break
    return found


def main():
    if len(sys.argv) < 2:
        sys.exit('Usage: python inspect_workbook.py "path to the workbook.xlsx"')
    warnings.simplefilter("ignore")
    workbook = openpyxl.load_workbook(sys.argv[1], data_only=True)

    sheets = {}
    for sheet in workbook.worksheets:
        sheets[sheet.title] = {"headings": headings_of(sheet), "visible": sheet.sheet_state == "visible"}
        hidden = "" if sheets[sheet.title]["visible"] else "  (hidden)"
        print(f'\nSheet "{sheet.title}"{hidden}: {sheet.max_row} rows')
        print("   " + (" | ".join(sheets[sheet.title]["headings"][:30]) or "(no headings found)"))

    values, notes = {}, {}

    # 1. The register: the sheet that covers most of what a bowtie needs.
    def register_score(title):
        found = guess_columns(sheets[title]["headings"], HINTS["Register sheet"])
        essentials = all(key in found for key in ("top_event", "cause", "control"))
        return (essentials, sheets[title]["visible"], len(found))
    register_title = max(sheets, key=register_score)
    choices = {"Register sheet": (register_title, guess_columns(sheets[register_title]["headings"],
                                                              HINTS["Register sheet"]))}

    # 2. The four lookup tabs: a sheet with both an ID column and a name column of the right kind.
    for where, word in TITLE_WORDS.items():
        best = None
        for title, info in sheets.items():
            if title == register_title:
                continue
            found = guess_columns(info["headings"], HINTS[where])
            if "id" in found and "name" in found:
                score = (word in loose(title), info["visible"], len(found))
                if best is None or score > best[0]:
                    best = (score, title, found)
        if best:
            choices[where] = (best[1], best[2])

    for where, setting, default, needed, meaning in SETTINGS:
        if where in ("Control type words", "Riskrunner import file"):
            values[(where, setting)] = default              # nothing to guess: keep the usual values
            notes[(where, setting)] = "usual value, not guessed"
        elif where not in choices:
            notes[(where, setting)] = "no such sheet found" if setting == "sheet" else ""
        elif setting == "sheet":
            values[(where, setting)] = choices[where][0]
            notes[(where, setting)] = "the sheet whose headings fit best"
        elif setting in choices[where][1]:
            values[(where, setting)], notes[(where, setting)] = choices[where][1][setting]
        else:
            notes[(where, setting)] = "not found on that sheet"

    write_mapping("mapping_suggested.xlsx", values, notes)

    print("\nBEST GUESS")
    for where, (title, found) in choices.items():
        print(f'  {where}: sheet "{title}"')
        for setting, (heading, how) in found.items():
            print(f"      {setting:22} -> {heading}   ({how})")
    missing = [where for where in TITLE_WORDS if where not in choices]
    if missing:
        print("  Not found: " + ", ".join(missing) + ". The program can work without them.")
    print("\nSaved as mapping_suggested.xlsx. Open it and check every yellow cell before using it.")


if __name__ == "__main__":
    main()
