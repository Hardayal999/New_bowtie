"""
check_login.py  -  the first test against the real Riskrunner. It only LOOKS.

The code version of Postman folder A. It answers three questions:
  1. Can this computer reach Riskrunner?
  2. Does logging in from a program work with your account?
  3. Is your account allowed to create assessments?

    python check_login.py

It sends three messages (GET /health, POST /token, GET /users/me/context) through the
same safety gate as the loader. None of them creates or changes anything.
Your password is typed in hidden and never saved.
"""

import getpass
import sys

from bowtie.riskrunner_api import SafeRiskrunner, RiskrunnerError, SafetyError
from bowtie.settings import RISKRUNNER_API


def main():
    client = SafeRiskrunner()
    print(f"Riskrunner address: {RISKRUNNER_API}")

    print("\n1. Is Riskrunner there?  (GET /health, needs no login)")
    try:
        client.is_reachable()
    except Exception as error:            # no internet, proxy, firewall ...
        sys.exit(f"   NO: {error}\n   Check the internet connection, or whether a company proxy blocks it.")
    print("   YES: Riskrunner answered.")

    print("\n2. Log in  (POST /token)")
    email = input("   Riskrunner email: ").strip()
    password = getpass.getpass("   Riskrunner password (hidden as you type): ")
    try:
        client.login(email, password)
    except RiskrunnerError as error:
        sys.exit(f"   NO: Riskrunner answered {error.status}. {error.reply}\n"
                 "   If you log in to Riskrunner through Microsoft or with a code, a program may not be able to.")
    print("   YES: logged in. The token (a temporary pass) is kept in memory only.")

    print("\n3. Who am I, and may I create assessments?  (GET /users/me/context)")
    try:
        me = client.who_am_i()
    except (RiskrunnerError, SafetyError) as error:
        sys.exit(f"   NO: {error}")
    membership = me.get("active_tenant_membership") or {}
    print(f'   Name:  {me.get("first_name", "")} {me.get("last_name", "")}')
    print(f'   Email: {me.get("email", "")}')
    may_create = membership.get("can_add_assessments")
    if may_create is True:
        print("   May create assessments: YES. The loader can make its own SANDBOX test assessment.")
    elif may_create is False:
        print("   May create assessments: NO. Ask the Riskrunner administrator before using the loader.")
    else:
        print("   May create assessments: Riskrunner did not say. The first loader run will show it.")

    print("\nDone. Nothing in Riskrunner was created or changed.")


if __name__ == "__main__":
    main()
