"""
compare_versions.py  -  shows what changed between two versions (works offline, touches nothing)

    python compare_versions.py "old import file.xlsx" "new import file.xlsx"

Both files must be in Riskrunner's import layout (a sheet called "Entities"),
for example two riskrunner_import.xlsx files made on different days.
The result is written to bowtie_output/changes.xlsx.

You rarely need to run this by hand: build_bowties.py does it automatically
every time, comparing the new import file with the one from the previous run.
"""

import sys
from pathlib import Path

from bowtie.compare import compare_files, describe_changes
from bowtie.settings import OUTPUT_FOLDER


def main():
    if len(sys.argv) != 3:
        sys.exit('Usage: python compare_versions.py "old import file.xlsx" "new import file.xlsx"')
    old_path, new_path = Path(sys.argv[1]), Path(sys.argv[2])
    for path in (old_path, new_path):
        if not path.exists():
            sys.exit(f'STOPPED: cannot find "{path}".')
    Path(OUTPUT_FOLDER).mkdir(exist_ok=True)
    out_path = Path(OUTPUT_FOLDER) / "changes.xlsx"
    changes = compare_files(old_path, new_path, out_path)
    print("\n".join(describe_changes(changes)))
    print(f"Details are in {out_path}")


if __name__ == "__main__":
    main()
