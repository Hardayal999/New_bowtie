"""
riskrunner_excel.py
Writes the bowties as Excel files in the layout Riskrunner imports.

The layout follows two real files: an export from Riskrunner, and an import file
prepared by the safety team. It is one sheet called "Entities". Each row is one
box, and each box names the box it hangs under:

    Entity     what kind of box: BowTieGroup, Hazard, TopEvent, Threat,
               Consequence or BowTieControl
    Id         a unique code for this row
    ParentId   the Id of the row it hangs under
    Code       left blank
    Name       the wording
    ...        optional detail columns, one per Riskrunner field

The Ids are built from the hazard log's own IDs, so they are readable and stay
the same every time the program runs:

    Hazard          CTX-001                                  (numbered by the program)
    TopEvent        WS3-HAZ-001
    Threat          WS3-HAZ-001_WS3-CAU-0001                 (top event _ cause)
    Consequence     WS3-HAZ-001_CSQ-002                      (top event _ consequence)
    BowTieControl   WS3-HAZ-001_WS3-CAU-0001_WS3-CTRL-0001   (its parent's Id _ control)

Two files are written:
    riskrunner_import.xlsx          with the detail columns (ratings, owner, status ...)
    riskrunner_import_minimal.xlsx  the five columns Riskrunner needs at minimum

Only ever import into a NEW, EMPTY assessment until the team knows how import behaves.
"""

import uuid
import warnings

import openpyxl

from bowtie.workbook import GuidedStop

MINIMUM_COLUMNS = ["Entity", "Id", "ParentId", "Code", "Name"]


def read_export(path):
    """From an export of the target assessment, take its column headings and its BowTieGroup Id."""
    warnings.simplefilter("ignore")
    workbook = openpyxl.load_workbook(path, data_only=True)
    if "Entities" not in workbook.sheetnames:
        raise GuidedStop(f'"{path}" does not look like a Riskrunner export: it has no sheet called "Entities".')
    rows = list(workbook["Entities"].iter_rows(values_only=True))
    headings = [h for h in rows[0] if h is not None]
    group_id = next((row[1] for row in rows[1:] if row[0] == "BowTieGroup"), None)

    # Safety: the file made here is meant for a NEW, EMPTY assessment only. If the export already
    # holds hazards, it came from an assessment that is in use, so refuse to build a file aimed at it.
    in_use = [row[4] for row in rows[1:] if row[0] == "Hazard"]
    if in_use:
        raise GuidedStop(f'"{path}" is an export of an assessment that already holds {len(in_use)} hazards '
                         f'(for example "{in_use[0]}").\n'
                         "To protect other people's work, the import file is only made for a NEW, EMPTY assessment.\n"
                         "Create a new assessment in Riskrunner, export that one, and use that export here.")
    return headings, group_id


def make_rows(bowties, mapping, group_id=None):
    """Turn the bowties into a list of rows. Each row is a dictionary: column name -> value."""
    names = mapping["riskrunner"]                       # the Riskrunner field names, from the mapping file
    suffix = names.get("rating_suffix", "")
    rating = lambda value: f"{value}{suffix}" if value else ""
    rows = []

    def add(entity, row_id, parent_id, name, details=None):
        row = {"Entity": entity, "Id": row_id, "ParentId": parent_id, "Code": "", "Name": name}
        for setting, value in (details or {}).items():
            if names.get(setting) and value:            # a blank field name in the mapping = do not write it
                row[names[setting]] = value
        rows.append(row)

    # The top row (BowTieGroup) needs an Id too. Use a fixed one, so it is the same on every run
    # and the change report does not see every hazard as "moved". An export of the target
    # assessment, when given, supplies that assessment's own group Id instead.
    group_id = group_id or str(uuid.uuid5(uuid.NAMESPACE_URL, "bowtie-tool/BowTieGroup"))
    add("BowTieGroup", group_id, None, None)

    # Hazards (the activities) have no ID in the hazard log, so number them in order of first appearance.
    hazard_ids = {}
    for bowtie in bowties.values():
        hazard = bowtie["hazard"] or "(no hazard recorded)"
        if hazard not in hazard_ids:
            hazard_ids[hazard] = f'{names.get("hazard_id_prefix", "CTX-")}{len(hazard_ids) + 1:03d}'
            add("Hazard", hazard_ids[hazard], group_id, hazard)

    for bowtie in bowties.values():
        top_event_id = bowtie["id"]
        add("TopEvent", top_event_id, hazard_ids[bowtie["hazard"] or "(no hazard recorded)"], bowtie["top_event"],
            {"field_top_event_id": top_event_id})

        for cause in bowtie["causes"].values():
            threat_id = f'{top_event_id}_{cause["id"]}'
            add("Threat", threat_id, top_event_id, cause["name"],
                {"field_initial_rating": rating(cause["initial_rating"]),
                 "field_residual_rating": rating(cause["residual_rating"]),
                 "field_cause_id": cause["id"], "field_work_package": cause["work_package"],
                 "field_life_cycle": cause["life_cycle"], "field_guideword": cause["guideword"]})
            for control in cause["controls"].values():
                add("BowTieControl", f'{threat_id}_{control["id"]}', threat_id, control["name"], control_details(control, rating))

        for consequence in bowtie["consequences"].values():
            consequence_id = f'{top_event_id}_{consequence["id"]}'
            add("Consequence", consequence_id, top_event_id, consequence["name"], {"field_top_event_id": top_event_id})
            for control in consequence["controls"].values():
                add("BowTieControl", f'{consequence_id}_{control["id"]}', consequence_id, control["name"],
                    control_details(control, rating))
    return rows


def control_details(control, rating):
    return {"field_initial_rating": rating(control.get("initial_rating", "")),
            "field_residual_rating": rating(control.get("residual_rating", "")),
            "field_control_id": control["id"], "field_control_hierarchy": control["hierarchy"],
            "field_control_type": control["type"], "field_control_owner": control["owner"],
            "field_control_status": control["status"]}


def detail_columns(mapping):
    """The detail columns, in a steady order: each field, then its (empty) comment column."""
    columns = ["Description"]
    for setting, field_name in mapping["riskrunner"].items():
        if setting.startswith("field_") and field_name and field_name not in columns:
            columns += [field_name, "Comment" + field_name]
    return columns


def write_rows(rows, headings, path):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Entities"
    sheet.append(headings)
    for row in rows:
        sheet.append([row.get(heading) for heading in headings])
    for letter, width in zip("ABCDE", (16, 44, 30, 8, 70)):
        sheet.column_dimensions[letter].width = width
    sheet.freeze_panes = "A2"
    workbook.save(path)


def write_import_files(bowties, mapping, folder, export_of_target=None):
    """Write the full file and the minimal file. Returns how many rows each holds."""
    headings, group_id = MINIMUM_COLUMNS + detail_columns(mapping), None
    if export_of_target:
        headings, group_id = read_export(export_of_target)     # use the target's own columns and group Id
    rows = make_rows(bowties, mapping, group_id)
    write_rows(rows, headings, folder / "riskrunner_import.xlsx")
    write_rows(rows, MINIMUM_COLUMNS, folder / "riskrunner_import_minimal.xlsx")
    return len(rows)


# ---------------------------------------------------------------------------
# Used by the loader when it uploads an import file itself
# ---------------------------------------------------------------------------

def read_rows(path):
    """Read an import file back into a list of row dictionaries."""
    sheet = openpyxl.load_workbook(path, data_only=True)["Entities"]
    values = list(sheet.iter_rows(values_only=True))
    headings = list(values[0])
    return [dict(zip(headings, row)) for row in values[1:] if any(cell is not None for cell in row)]


def select_rows(rows, top_event_id=None):
    """Keep everything, or only one top event with what hangs under it and what it hangs under."""
    if not top_event_id:
        return rows
    chosen = [row for row in rows if row["Entity"] == "TopEvent" and row["Id"] == top_event_id]
    if not chosen:
        return []
    keep = {top_event_id, chosen[0]["ParentId"]}                # the top event and its hazard
    keep |= {row["Id"] for row in rows if row["Entity"] == "BowTieGroup"}
    changed = True
    while changed:                                              # then everything underneath, level by level
        changed = False
        for row in rows:
            if row["ParentId"] in keep and row["Id"] not in keep and row["Entity"] not in ("Hazard", "TopEvent"):
                keep.add(row["Id"])
                changed = True
    return [row for row in rows if row["Id"] in keep]
