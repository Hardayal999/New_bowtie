"""
loader.py
The steps that put bowties into Riskrunner, in order.
It only ever talks to Riskrunner through SafeRiskrunner (riskrunner_api.py).
"""

import json
import time
from datetime import datetime
from pathlib import Path

from bowtie.settings import OUTPUT_FOLDER, RECORD_FILE, RISKRUNNER_SITE, SANDBOX_PREFIX
from bowtie.riskrunner_api import RiskrunnerError
from bowtie.riskrunner_excel import MINIMUM_COLUMNS, read_rows, select_rows, write_rows


def read_tree(path):
    """Read riskrunner_tree.json, the file made by build_bowties.py."""
    return json.loads(Path(path).read_text(encoding="utf-8"))["hazards"]


def choose(hazards, only_id=None):
    """Keep everything, or keep only the one bowtie whose ID was asked for."""
    if not only_id:
        return hazards
    chosen = []
    for hazard in hazards:
        top_events = [t for t in hazard["top_events"]
                      if t["element_name"] == only_id or t["element_name"].startswith(only_id + ":")]
        if top_events:
            chosen.append({"element_name": hazard["element_name"], "top_events": top_events})
    return chosen


def describe(hazards):
    """Count what would be sent, as plain text lines."""
    lines = []
    for hazard in hazards:
        lines.append(f'  Hazard: {hazard["element_name"]}')
        for top_event in hazard["top_events"]:
            causes = len(top_event["threats"])
            left = sum(len(t["barriers"]) for t in top_event["threats"])
            right = sum(len(c["barriers"]) for c in top_event["consequences"])
            lines.append(f'    {top_event["element_name"]}  '
                         f'({causes} causes, {left} controls left, {right} controls right, '
                         f'{len(top_event["consequences"])} consequences)')
    return lines


def prepare_import_file(only_id=None):
    """
    Make the Excel file the loader will upload: the minimal import file from build_bowties.py,
    cut down to one bowtie if one was asked for. Returns (path, number of rows), or (None, 0).
    """
    source = Path(OUTPUT_FOLDER) / "riskrunner_import_minimal.xlsx"
    if not source.exists():
        return None, 0
    rows = select_rows(read_rows(source), only_id)
    if not rows:
        return None, 0
    target = Path(OUTPUT_FOLDER) / "riskrunner_import_sent.xlsx"
    write_rows(rows, MINIMUM_COLUMNS, target)
    return target, len(rows)


def read_records():
    """The assessments this tool created on this computer (newest last)."""
    path = Path(RECORD_FILE)
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


def record_assessment(assessment, method):
    """Write down a new assessment, so a later run may update it (and only it)."""
    records = read_records()
    records.append({"id": assessment["id"], "name": assessment["name"], "method": method,
                    "created": datetime.now().isoformat(timespec="seconds"),
                    "address": f'{RISKRUNNER_SITE}/assessments/{assessment["id"]}'})
    Path(RECORD_FILE).write_text(json.dumps(records, indent=2), encoding="utf-8")


def connect(client, email, password, say):
    """Steps 1 to 3, the same for every run."""
    say("1. Checking Riskrunner can be reached ...")
    client.is_reachable()

    say("2. Logging in ...")
    client.login(email, password)

    say("3. Checking who you are and what you may do ...")
    me = client.who_am_i()
    say(f'   Logged in as {me.get("first_name", "")} {me.get("last_name", "")} ({me.get("email", "")})')
    return me


def run_load(client, hazards, email, password, method="messages", import_file=None, say=print, pause=time.sleep):
    """
    Do the real load into a NEW assessment. Returns the address of that assessment.

    method "messages": send each hazard as an "add hazard" message.
    method "import":   upload import_file, an Excel file in Riskrunner's import layout.
    Steps 1 to 4 are the same for both.
    """
    me = connect(client, email, password, say)
    membership = me.get("active_tenant_membership") or {}
    if membership.get("can_add_assessments") is False:
        raise PermissionError("Your account is not allowed to create assessments. "
                              "Ask your Riskrunner administrator for that right.")

    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    name = f'{SANDBOX_PREFIX} - {me.get("first_name") or "user"} - {stamp} - safe to delete'
    say(f'4. Creating a new, empty assessment called "{name}" ...')
    assessment = client.create_sandbox_assessment(
        name, "Created by the bowtie loader for testing. Contains test data only. Safe to delete.")
    record_assessment(assessment, method)
    address = f'{RISKRUNNER_SITE}/assessments/{assessment["id"]}'
    say(f"   Created: {address}")
    say(f"   Written down in {RECORD_FILE}, so a later run can update it.")

    if method == "import":
        load_by_import(client, assessment, import_file, len(hazards), say, pause)
    else:
        load_by_messages(client, assessment, hazards, say)
    return address


def run_update(client, assessment_id, import_file, email, password, say=print, pause=time.sleep):
    """
    Upload a NEW version of the import file into a test assessment this tool created earlier,
    inside a new editing session (review) that is left open for a person to check.
    Counts the causes before and after, so you can see whether Riskrunner updated or duplicated.
    """
    connect(client, email, password, say)

    say("4. Checking the assessment is one this tool created ...")
    recorded = [record["id"] for record in read_records()]
    details = client.trust_recorded_assessment(assessment_id, recorded)
    address = f"{RISKRUNNER_SITE}/assessments/{assessment_id}"
    say(f'   OK: "{details.get("name")}"')

    say("5. Counting the causes it holds now ...")
    before = client.count_threats(assessment_id)
    say(f"   Causes before: {before}")

    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    say("6. Opening a new editing session (review) for the update ...")
    review = client.open_review(assessment_id, f"Bowtie update {stamp}")

    say(f"7. Uploading {import_file} into that review ...")
    client.upload_import_file(assessment_id, import_file, review_id=review["id"])

    say("8. Waiting for Riskrunner to finish (it works in the background) ...")
    after = before
    for _ in range(24):                       # look every 5 seconds, for up to 2 minutes
        pause(5)
        after = client.count_threats(assessment_id)
        if after != before:
            break
    say(f"   Causes after: {after}")
    if after == before:
        say("   No change in the count. Either Riskrunner matched every row to what was already there,")
        say("   or the import has not finished. Open the review in your browser to see which.")
    elif before and after and after >= 2 * before:
        say("   The count roughly doubled: Riskrunner probably ADDED a second copy instead of updating.")
    else:
        say("   The count changed. Open the review in your browser to see what was added or changed.")
    say("   The review is left OPEN. In Riskrunner, finish it to keep the changes, or delete it to throw them away.")
    return address


def load_by_messages(client, assessment, hazards, say):
    say("5. Opening an editing session in that assessment ...")
    review = client.open_review(assessment["id"], "Bowtie load")

    say("6. Sending the bowties, one hazard at a time ...")
    for number, hazard in enumerate(hazards, start=1):
        client.add_hazard(review["id"], hazard)
        say(f'   {number} of {len(hazards)} sent: {hazard["element_name"]} '
            f'({len(hazard["top_events"])} bowties)')

    say("7. Reading back what the new assessment now holds ...")
    count = client.count_hazards(assessment["id"])
    say(f"   Riskrunner reports {count} hazards in the new assessment (sent: {len(hazards)}).")


def load_by_import(client, assessment, file_path, hazards_sent, say, pause):
    say(f"5. Using the import file {file_path} ...")

    say("6. Uploading it into the new assessment ...")
    try:
        client.upload_import_file(assessment["id"], file_path)
    except RiskrunnerError as error:
        if error.status not in (400, 403, 409, 422):
            raise
        say("   Riskrunner did not accept it directly. Trying again inside an editing session ...")
        review = client.open_review(assessment["id"], "Bowtie import")
        client.upload_import_file(assessment["id"], file_path, review_id=review["id"])

    say("7. Waiting for Riskrunner to finish the import (it works in the background) ...")
    count = 0
    for _ in range(24):                       # look every 5 seconds, for up to 2 minutes
        count = client.count_hazards(assessment["id"]) or 0
        if count:
            break
        pause(5)
    if count:
        say(f"   Riskrunner reports {count} hazards in the new assessment (sent: {hazards_sent}).")
    else:
        say("   After 2 minutes Riskrunner still reports no hazards. The import may have been refused, "
            "or may still be running. Open the assessment in your browser to look.")


def save_log(client, path):
    """Write the record of every message sent. It holds no password and no token."""
    Path(path).write_text(json.dumps(client.log, indent=2), encoding="utf-8")
