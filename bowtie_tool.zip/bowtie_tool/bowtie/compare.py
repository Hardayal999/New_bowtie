"""
compare.py
Compares two import files and lists what changed between them.

Why this works: every row's Id is built from the hazard log's own IDs, for example
    WS3-HAZ-001_WS3-CAU-0001
so the same box has the same Id every time the program runs. Two versions can
therefore be matched row by row on the Id, like matching two lists by a key.

Kinds of change found:
    Added         an Id that is only in the new file      (a new box)
    Removed       an Id that is only in the old file      (a box that has gone)
    Renamed       same Id, different Name                 (the wording changed)
    Moved         same Id, different ParentId             (it now hangs under another box)
    Detail        same Id, a detail column changed        (e.g. Residual Risk, Control Status)

Nothing here talks to Riskrunner.
"""

from collections import Counter

import openpyxl

from bowtie.riskrunner_excel import read_rows

IGNORED = {"Id", "Entity", "Code", "Description"}
ORDER = {"Added": 0, "Removed": 1, "Renamed": 2, "Moved": 3, "Detail": 4}


def compare_rows(old_rows, new_rows):
    # The top row (BowTieGroup) is left out, and any pointer to it is treated as the same,
    # because two files can carry different group Ids for the same top.
    groups = {row["Id"] for row in list(old_rows) + list(new_rows) if row.get("Entity") == "BowTieGroup"}
    old = {row["Id"]: row for row in old_rows if row.get("Entity") != "BowTieGroup"}
    new = {row["Id"]: row for row in new_rows if row.get("Entity") != "BowTieGroup"}
    text = lambda value: "TOP" if value in groups else ("" if value is None else str(value).strip())
    changes = []

    def add(kind, row, column="", before="", after=""):
        changes.append({"Change": kind, "Box": row["Entity"], "Id": row["Id"], "Name": text(row.get("Name")),
                        "Column": column, "Before": before, "After": after})

    for row_id in new.keys() - old.keys():
        add("Added", new[row_id])
    for row_id in old.keys() - new.keys():
        add("Removed", old[row_id])
    for row_id in new.keys() & old.keys():
        before, after = old[row_id], new[row_id]
        if text(before.get("Name")) != text(after.get("Name")):
            add("Renamed", after, "Name", text(before.get("Name")), text(after.get("Name")))
        if text(before.get("ParentId")) != text(after.get("ParentId")):
            add("Moved", after, "ParentId", text(before.get("ParentId")), text(after.get("ParentId")))
        for column in sorted((set(before) | set(after)) - IGNORED - {"Name", "ParentId"}):
            if column.startswith("Comment"):
                continue
            if text(before.get(column)) != text(after.get(column)):
                add("Detail", after, column, text(before.get(column)), text(after.get(column)))

    changes.sort(key=lambda c: (ORDER[c["Change"]], c["Id"], c["Column"]))
    return changes


def write_changes(changes, path, old_name, new_name):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Changes"
    columns = ["Change", "Box", "Id", "Name", "Column", "Before", "After"]
    sheet.append(columns)
    for change in changes:
        sheet.append([change[column] for column in columns])
    for letter, width in zip("ABCDEFG", (10, 15, 44, 50, 24, 40, 40)):
        sheet.column_dimensions[letter].width = width
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions

    summary = workbook.create_sheet("Summary")
    summary.append(["Old file", old_name])
    summary.append(["New file", new_name])
    summary.append([])
    summary.append(["Change", "Box", "Count"])
    for (kind, box), count in sorted(Counter((c["Change"], c["Box"]) for c in changes).items(),
                                     key=lambda item: (ORDER[item[0][0]], item[0][1])):
        summary.append([kind, box, count])
    if not changes:
        summary.append(["No changes", "", 0])
    summary.column_dimensions["A"].width = 12
    summary.column_dimensions["B"].width = 40
    workbook.save(path)


def compare_files(old_path, new_path, out_path):
    changes = compare_rows(read_rows(old_path), read_rows(new_path))
    write_changes(changes, out_path, str(old_path), str(new_path))
    return changes


def describe_changes(changes):
    """A few plain lines for the screen."""
    if not changes:
        return ["No changes since the previous version."]
    counts = Counter(c["Change"] for c in changes)
    return [f"Changes since the previous version: " +
            ", ".join(f"{counts[kind]} {kind.lower()}" for kind in ORDER if counts[kind])]
