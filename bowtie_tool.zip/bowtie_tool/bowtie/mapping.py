"""
mapping.py
The mapping file (mapping.xlsx) tells the program where things are in ONE
project's hazard log, and what the columns are called in Riskrunner.

It is an ordinary Excel sheet with one row per setting:

    Where | Setting | In your workbook | Needed? | What it means

Only the yellow column, "In your workbook", is meant to be edited.
"(none)" in a yellow cell means "my workbook does not have this". An empty cell means the same.

This file holds the list of every setting (SETTINGS below), writes a mapping
workbook from it, and reads one back.
"""

import json
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

# (where, setting, default value, needed?, what it means)
# "where" is shown to people; SECTION_KEYS turns it into the name the program uses.
SETTINGS = [
    # ---- the register sheet -------------------------------------------------------------------
    ("Register sheet", "sheet", "Register-View-All", "Required",
     "The name of the main sheet: the one with a row for each hazard / cause / consequence / control."),
    ("Register sheet", "top_event", "Hazards", "Required",
     "The column holding the top event (the moment control is lost). In many logs this column is headed 'Hazard'."),
    ("Register sheet", "top_event_id", "", "Optional",
     "Fill in ONLY if the top event's ID is in its own column. Write (none) if ID and wording share a cell as 'ID: wording'."),
    ("Register sheet", "hazard", "", "Optional",
     "The column holding the hazard (the activity, such as 'Operating road users'), if the register has one. "
     "Write (none) if it is on a separate Hazards tab."),
    ("Register sheet", "cause", "Causes", "Required", "The column holding the cause."),
    ("Register sheet", "cause_id", "", "Optional", "Fill in ONLY if the cause's ID is in its own column."),
    ("Register sheet", "consequence", "Consequences", "Optional", "The column holding the consequence."),
    ("Register sheet", "consequence_id", "", "Optional", "Fill in ONLY if the consequence's ID is in its own column."),
    ("Register sheet", "control", "Controls", "Required", "The column holding the control."),
    ("Register sheet", "control_id", "", "Optional", "Fill in ONLY if the control's ID is in its own column."),
    ("Register sheet", "control_type", "Control Type", "Optional",
     "The column saying whether a control prevents (left side) or mitigates (right side)."),
    ("Register sheet", "control_hierarchy", "Control Hierarchy", "Optional", "The kind of control, e.g. Engineering."),
    ("Register sheet", "control_owner", "Control Owner Allocation", "Optional", "Who owns the control."),
    ("Register sheet", "control_status", "Control Status", "Optional", "The progress of the control, e.g. Open."),
    ("Register sheet", "initial_likelihood", "Initial Likelihood", "Optional", "Likelihood before controls."),
    ("Register sheet", "initial_consequence", "Initial Consequences", "Optional", "Severity before controls."),
    ("Register sheet", "initial_rating", "Initial Rating", "Optional", "Overall rating before controls, e.g. Medium."),
    ("Register sheet", "residual_likelihood", "Residual Likelihood", "Optional", "Likelihood after controls."),
    ("Register sheet", "residual_consequence", "Residual Consequences", "Optional", "Severity after controls."),
    ("Register sheet", "residual_rating", "Residual Rating", "Optional", "Overall rating after controls."),
    ("Register sheet", "work_package", "Works Package Allocation", "Optional", "The work package a cause belongs to."),
    ("Register sheet", "life_cycle", "Design Life Cycle Stage", "Optional", "The project stage a cause applies to."),
    ("Register sheet", "guideword", "Guideword", "Optional", "The guideword used to find the cause."),
    # ---- the four lookup tabs (all optional) ---------------------------------------------------
    ("Hazards tab", "sheet", "Hazards", "Optional",
     "A sheet listing every top event once. Write (none) if the workbook has no such sheet."),
    ("Hazards tab", "id", "Hazard ID", "Optional", "The column holding each top event's ID."),
    ("Hazards tab", "name", "Hazard", "Optional", "The column holding each top event's wording."),
    ("Hazards tab", "hazard", "Context", "Optional",
     "The column holding the hazard (the activity) that each top event belongs to."),
    ("Causes tab", "sheet", "Causes", "Optional", "A sheet listing every cause once."),
    ("Causes tab", "id", "Cause ID", "Optional", "The column holding each cause's ID."),
    ("Causes tab", "name", "Cause", "Optional", "The column holding each cause's wording."),
    ("Causes tab", "top_event_ids", "Hazard ID", "Optional",
     "The column listing which top events the cause belongs to (IDs separated by commas)."),
    ("Causes tab", "consequence_ids", "Consequence ID", "Optional",
     "The column listing which consequences the cause can lead to (IDs separated by commas)."),
    ("Causes tab", "initial_rating", "Initial Rating", "Optional", "Overall rating before controls."),
    ("Causes tab", "residual_rating", "Residual Rating", "Optional", "Overall rating after controls."),
    ("Causes tab", "work_package", "Works Package Allocation", "Optional", "The work package a cause belongs to."),
    ("Causes tab", "life_cycle", "Design Life Cycle Stage", "Optional", "The project stage a cause applies to."),
    ("Causes tab", "guideword", "Guideword", "Optional", "The guideword used to find the cause."),
    ("Controls tab", "sheet", "Controls", "Optional", "A sheet listing every control once."),
    ("Controls tab", "id", "Control ID", "Optional", "The column holding each control's ID."),
    ("Controls tab", "name", "Control Measure", "Optional", "The column holding each control's wording."),
    ("Controls tab", "type", "Control Type", "Optional", "Preventative or Mitigative."),
    ("Controls tab", "hierarchy", "Control Hierarchy", "Optional", "The kind of control."),
    ("Controls tab", "owner", "Control Owner Allocation", "Optional", "Who owns the control."),
    ("Controls tab", "status", "Control Status", "Optional", "The progress of the control."),
    ("Controls tab", "cause_ids", "Cause ID", "Optional",
     "The column listing which causes the control guards against (IDs separated by commas)."),
    ("Consequences tab", "sheet", "Consequences", "Optional", "A sheet listing every consequence once."),
    ("Consequences tab", "id", "Consequence ID", "Optional", "The column holding each consequence's ID."),
    ("Consequences tab", "name", "Consequences", "Optional", "The column holding each consequence's wording."),
    # ---- the words that decide a control's side ------------------------------------------------
    ("Control type words", "left_side_words", "Preventative, Preventive, Prevention", "Required",
     "The words in the control type column that mean 'acts BEFORE the top event'. Separate with commas. "
     "'Preventative' is the word in the sample log; the others are alternative spellings another project might use."),
    ("Control type words", "right_side_words", "Mitigative, Mitigating, Mitigation, Recovery", "Required",
     "The words that mean 'acts AFTER the top event'. 'Mitigative' and 'Recovery' are in the sample log's Lists sheet."),
    ("Control type words", "side_when_type_is_missing", "unknown", "Required",
     "What to do with a control whose type cell is blank: 'unknown' (flag it), 'left' or 'right'."),
    # ---- the Riskrunner import file ------------------------------------------------------------
    ("Riskrunner import file", "hazard_id_prefix", "CTX-", "Required",
     "Hazards (the activities) have no ID in the log, so the program numbers them: CTX-001, CTX-002 ..."),
    ("Riskrunner import file", "rating_suffix", " Risk", "Optional",
     "Text added after a rating so it matches Riskrunner's wording: 'Medium' becomes 'Medium Risk'. (none) = add nothing."),
    ("Riskrunner import file", "field_top_event_id", "Hazard ID", "Optional",
     "The Riskrunner field that carries the top event's ID. (none) = do not write it."),
    ("Riskrunner import file", "field_initial_rating", "Initial Risk", "Optional", "Riskrunner field for the rating before controls."),
    ("Riskrunner import file", "field_residual_rating", "Residual Risk", "Optional", "Riskrunner field for the rating after controls."),
    ("Riskrunner import file", "field_cause_id", "Cause ID", "Optional", "Riskrunner field for the cause's ID."),
    ("Riskrunner import file", "field_work_package", "Work Package Allocation", "Optional", "Riskrunner field for the work package."),
    ("Riskrunner import file", "field_life_cycle", "Project Life Cycle", "Optional", "Riskrunner field for the project stage."),
    ("Riskrunner import file", "field_guideword", "Guidewords", "Optional", "Riskrunner field for the guideword."),
    ("Riskrunner import file", "field_control_id", "Control ID", "Optional", "Riskrunner field for the control's ID."),
    ("Riskrunner import file", "field_control_hierarchy", "Control Hierarchy", "Optional", "Riskrunner field for the kind of control."),
    ("Riskrunner import file", "field_control_type", "Control Type", "Optional", "Riskrunner field for Preventative / Mitigative."),
    ("Riskrunner import file", "field_control_owner", "Control Owner Allocation", "Optional", "Riskrunner field for the control's owner."),
    ("Riskrunner import file", "field_control_status", "Control Status", "Optional", "Riskrunner field for the control's status."),
]

SECTION_KEYS = {"Register sheet": "register", "Hazards tab": "hazards_tab", "Causes tab": "causes_tab",
                "Controls tab": "controls_tab", "Consequences tab": "consequences_tab",
                "Control type words": "words", "Riskrunner import file": "riskrunner"}

HEADINGS = ["Where", "Setting", "In your workbook", "Needed?", "What it means"]
NONE = "(none)"


def default_mapping():
    """The mapping as nested dictionaries, with the default values."""
    return rows_to_mapping([(where, setting, value) for where, setting, value, _, _ in SETTINGS])


def rows_to_mapping(rows):
    mapping = {key: {} for key in SECTION_KEYS.values()}
    for where, setting, value in rows:
        section = SECTION_KEYS.get(str(where).strip())
        if not section or not setting:
            continue
        text = "" if value is None else str(value)
        if text.strip().lower() in (NONE.lower(), "-"):
            text = ""                                   # "(none)" means "this workbook does not have it"
        if section == "riskrunner":
            mapping[section][setting] = text            # keep spaces: " Risk" starts with one on purpose
        else:
            # "A | B" means: either heading is fine.
            options = [part.strip() for part in text.split("|") if part.strip()]
            mapping[section][setting] = options if len(options) > 1 else (options[0] if options else "")
    words = mapping.pop("words")
    split = lambda text: [w.strip() for w in str(text).split(",") if w.strip()]
    mapping["left_side_words"] = split(words.get("left_side_words", ""))
    mapping["right_side_words"] = split(words.get("right_side_words", ""))
    mapping["side_when_type_is_missing"] = words.get("side_when_type_is_missing", "unknown") or "unknown"
    return mapping


def write_mapping(path, values=None, notes=None):
    """
    Write a mapping workbook.
      values  {(where, setting): value} to use in place of the defaults (used by inspect_workbook.py)
      notes   {(where, setting): text} shown in an extra column, e.g. how a value was guessed
    """
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Mapping"
    sheet.append(HEADINGS + (["How it was guessed"] if notes is not None else []))
    yellow = PatternFill("solid", start_color="FFF2CC")
    for where, setting, default, needed, meaning in SETTINGS:
        value = default if values is None else values.get((where, setting), "")
        row = [where, setting, value if str(value).strip() else NONE, needed, meaning]
        if notes is not None:
            row.append(notes.get((where, setting), ""))
        sheet.append(row)
        sheet.cell(row=sheet.max_row, column=3).fill = yellow
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for letter, width in zip("ABCDEF", (24, 26, 40, 11, 100, 44)):
        sheet.column_dimensions[letter].width = width
    for row in sheet.iter_rows(min_row=2):
        row[4].alignment = Alignment(wrap_text=True, vertical="top")
    sheet.freeze_panes = "A2"

    help_sheet = workbook.create_sheet("How to use")
    for line in [
        "This workbook tells the bowtie program where things are in YOUR hazard log.",
        "",
        "Only change the yellow column, 'In your workbook', on the Mapping sheet.",
        "Type the sheet name or column heading exactly as it appears in your hazard log.",
        "Capital letters and extra spaces do not matter.",
        "Write (none) in a yellow cell if your hazard log does not have that thing.",
        "Only the rows marked 'Required' must be filled in.",
        "If a column could have one of two headings, write both with a | between them:  Causes | Cause",
        "",
        "Do not change the 'Where' or 'Setting' columns. The program finds each line by them.",
        "",
        "To start a mapping for a hazard log you have not used before, run:",
        '    python inspect_workbook.py "your hazard log.xlsx"',
        "It writes mapping_suggested.xlsx with its best guesses. Check every yellow cell before using it.",
    ]:
        help_sheet.append([line])
    help_sheet.column_dimensions["A"].width = 110
    workbook.save(path)


def read_mapping(path):
    """Read a mapping workbook (or an older mapping.json) into nested dictionaries."""
    from bowtie.workbook import GuidedStop   # imported here to avoid a circular import
    path = Path(path)
    if not path.exists():
        raise GuidedStop(f'Cannot find the mapping file "{path}". It should sit next to build_bowties.py.')

    if path.suffix.lower() == ".json":       # the older format is still understood
        try:
            old = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as error:
            raise GuidedStop(f'The mapping file "{path}" has a typing mistake near line {error.lineno}: {error.msg}.')
        mapping = default_mapping()
        for key, value in old.items():
            if not key.startswith("_"):
                mapping[key] = value
        return mapping

    workbook = openpyxl.load_workbook(path, data_only=True)
    if "Mapping" not in workbook.sheetnames:
        raise GuidedStop(f'"{path}" is not a mapping workbook: it has no sheet called "Mapping".')
    rows = [(row[0], row[1], row[2]) for row in workbook["Mapping"].iter_rows(min_row=2, values_only=True)
            if row and row[0] and row[1]]
    mapping = default_mapping()
    given = rows_to_mapping(rows)
    for key, value in given.items():
        if key == "riskrunner":
            mapping[key].update(value)                    # lines that are absent keep their defaults
        elif isinstance(value, dict):
            # For the hazard log, a line that is absent means "this workbook does not have it".
            mapping[key] = {setting: value.get(setting, "") for setting in mapping[key]}
        elif value:
            mapping[key] = value
    return mapping
