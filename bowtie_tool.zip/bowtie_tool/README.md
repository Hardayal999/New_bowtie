# Bowtie tool

Turns a hazard log workbook into bowties, checks them, and (optionally) loads
them into a NEW test assessment in Riskrunner.

## The steps

| Step | Command | Needs | Touches Riskrunner? |
| --- | --- | --- | --- |
| 0. Inspect (new workbooks only) | `python inspect_workbook.py "workbook.xlsx"` | openpyxl | No |
| 1. Build | `python build_bowties.py "workbook.xlsx"` | openpyxl | No |
| 2a. Check the login (reads only) | `python check_login.py` | requests, your login | Reads only |
| 2b. Load | `python load_into_riskrunner.py` | requests, your login | Only with `--send` |

Install the two add-ons once:

    pip install openpyxl requests

## Step 1: build (offline)

    python build_bowties.py "Project_HL_FOR_CODE.xlsx"

Writes into the folder `bowtie_output`:

| File | What it is |
| --- | --- |
| bowties.html | A picture of every bowtie. Look at this before loading anything. |
| checks.xlsx | Every gap or mismatch: where it was found, where to fix it |
| riskrunner_import.xlsx | The bowties in Riskrunner's import layout, with detail columns |
| riskrunner_import_minimal.xlsx | The same, with only the five columns Riskrunner needs |
| riskrunner_tree.json | The bowties in the layout the loader program sends |
| changes.xlsx | What changed since the previous run (from the second run on) |
| riskrunner_import_previous.xlsx | The import file from the previous run, kept for that comparison |

## The mapping file: mapping.xlsx

The program does not know what your sheets and columns are called. The mapping
file tells it. It is an ordinary Excel sheet with one line per thing the program
needs:

| Where | Setting | In your workbook | Needed? | What it means |
| --- | --- | --- | --- | --- |
| Register sheet | cause | Causes | Required | The column holding the cause. |
| Register sheet | hazard | (none) | Optional | The column holding the hazard, if the register has one. |

- Only the yellow column, "In your workbook", is meant to be changed.
- Type the sheet name or column heading as it appears in your hazard log.
  Capital letters and extra spaces do not matter.
- "(none)" in a yellow cell means "my hazard log does not have this".
- Only the lines marked Required must be filled in.

The last two groups of lines are not about the hazard log:
- "Control type words" lists the words that put a control on the left or the right.
- "Riskrunner import file" lists what the detail columns are called in Riskrunner.

## Using a different project's hazard log

1. Run `python inspect_workbook.py "Other project.xlsx"`. It lists every sheet
   and heading, and writes its best guess for every line to `mapping_suggested.xlsx`,
   with a column saying how each guess was made.
2. Open `mapping_suggested.xlsx` and check every yellow cell. The guess comes
   from the wording of the headings and can be wrong.
3. Run `python build_bowties.py "Other project.xlsx" --mapping mapping_suggested.xlsx`.

What the program copes with on its own:

| Difference | What happens |
| --- | --- |
| Sheets or columns have other names | Put the names in the mapping file |
| Capital letters, extra spaces, punctuation in a heading | Ignored |
| Title lines above the headings | The heading row is found automatically |
| No Hazards / Causes / Controls / Consequences tabs | It builds from the register sheet alone |
| A column is missing (ratings, owner, status, consequence) | It carries on and lists it in checks.xlsx |
| ID and name in one cell ("ID: name"), in two columns, or no IDs | All three are understood |
| No control type column | Reported once; or set `side_when_type_is_missing` to `left` |

Only three things are essential: a top event column, a cause column and a
control column. If one cannot be found, the program stops, says what it looked
for, shows the similar headings it did find, and tells you which line of the
mapping file to change. Nothing is written in that case.

What it does NOT cope with: a log with a different structure, for example
several controls typed into one cell, or preventive and mitigating controls in
two separate columns. That needs a change in `bowtie/workbook.py`. The other
files stay as they are.

## Step 2, route A: Riskrunner's own Excel import (by hand, no password)

The build writes two import files in Riskrunner's layout: one sheet called
"Entities", one row per box, each row naming the row it hangs under.

| File | Columns |
| --- | --- |
| riskrunner_import.xlsx | Entity, Id, ParentId, Code, Name, plus detail columns (ratings, owner, status ...) |
| riskrunner_import_minimal.xlsx | Entity, Id, ParentId, Code, Name only |

Use the minimal file for an assessment that has no custom fields. Use the full
file for an assessment whose fields have the names listed under "Riskrunner
import file" in the mapping.

The Ids are readable and stay the same on every run, for example
`WS3-HAZ-001_WS3-CAU-0001_WS3-CTRL-0001` for a control under a cause.

1. In Riskrunner, create a NEW assessment. Never use one that other people work in.
2. Export that new, empty assessment to Excel.
3. Run `python build_bowties.py "workbook.xlsx" --riskrunner-export "that export.xlsx"`.
   The program refuses an export that already holds hazards.
4. In the new assessment, use Import and choose one of the two files.

Status: the full file was compared with an import file the safety team prepared
from the same hazard log. All 725 rows the two have in common are identical in
all 30 columns. Importing it has not been tried from this work. It is not known
whether importing adds to an assessment or replaces what is there.

## Step 2, routes B and C: the loader program

    python load_into_riskrunner.py                             # practice run, sends nothing
    python load_into_riskrunner.py --send --only WS3-HAZ-030   # load ONE bowtie
    python load_into_riskrunner.py --send --all                # load all of them
    python load_into_riskrunner.py --send --only WS3-HAZ-030 --method import

Route B (the default, `--method messages`) sends each hazard as an "add hazard"
message. Route C (`--method import`) uploads the minimal import file, which is
what a person does with Import in route A.
Both create a new assessment and both obey the same safety rules.

It asks you to type YES, then your email and password. The password is not saved.
It always creates a new assessment named "SANDBOX bowtie test - ...".
To remove a test assessment afterwards, delete it by hand in Riskrunner.

## When the hazard log changes

1. Run `build_bowties.py` again. It keeps the previous import file as
   `riskrunner_import_previous.xlsx` and writes `changes.xlsx`: every box added,
   removed, renamed or moved, and every detail changed. This works because every
   row's Id is built from the hazard log's own IDs, so it stays the same between runs.
2. Either make a fresh test assessment (a normal load), or upload the new file
   into the test assessment the tool made last time:

       python load_into_riskrunner.py --all --update last          # practice run
       python load_into_riskrunner.py --send --all --update last   # real run

   The update opens a new review in that assessment, uploads the new import file
   into it, counts the causes before and after, and leaves the review OPEN for a
   person to check in Riskrunner (finish it to keep, delete it to throw away).

The tool only updates assessments listed in `my_sandbox_assessments.json`, which
it writes itself when it creates one, and only if Riskrunner confirms the name
still starts with "SANDBOX bowtie test". Status: not yet tried on the real
Riskrunner. Whether a re-import updates the existing boxes or adds a second
copy is exactly what the first update test will show.

To compare any two import files by hand (for example yours and a colleague's):

    python compare_versions.py "old.xlsx" "new.xlsx"

## Trying the calls by hand in Postman

The folder `postman` holds a ready-made collection with one request for each
kind of message the loader sends. Import it into Postman, put your email and
password in the collection's Variables tab (Current value column only), and run
the requests in order. Postman has no safety gate of its own: only use the
requests in the collection.

## Safety

Run this any time. It needs no login and no internet:

    python test_safety.py

It proves that the program refuses to delete, rename or write to anything it
did not create in the same run. The rules are at the top of
`bowtie/riskrunner_api.py`.

## Where things are

| File | Job | Change it when |
| --- | --- | --- |
| mapping.xlsx | Says where things are in the hazard log | Every new project (use a copy) |
| inspect_workbook.py | Lists a workbook's sheets and headings, guesses a mapping | Rarely |
| check_login.py | First online test: reachable, login works, may create assessments. Reads only | Rarely |
| compare_versions.py | Compares two import files and writes changes.xlsx | Rarely |
| my_sandbox_assessments.json | Written by the loader: the test assessments it created | Never by hand |
| build_bowties.py | Runs step 1 | Rarely |
| load_into_riskrunner.py | Runs step 2 | Rarely |
| test_safety.py | Proves the safety rules hold | You add a new allowed call |
| postman/ | A Postman collection of every call the loader sends | Riskrunner's messages change |
| bowtie/settings.py | Output folder and the Riskrunner web address | The address changes |
| bowtie/mapping.py | Reads and writes the mapping file; lists every setting | You add a new setting |
| bowtie/workbook.py | Reads the Excel sheets using the mapping | A log has a different structure |
| bowtie/builder.py | Turns rows into bowties | The rule for placing a control changes |
| bowtie/checks.py | Finds gaps and mismatches | You want a new check |
| bowtie/report.py | Writes checks.xlsx | You want different columns |
| bowtie/preview.py | Writes bowties.html | You want a different look |
| bowtie/riskrunner_excel.py | Writes the two Riskrunner import files | Riskrunner's import layout changes |
| bowtie/riskrunner_file.py | Writes riskrunner_tree.json | Riskrunner's message layout changes |
| bowtie/riskrunner_api.py | The only file that talks to Riskrunner; holds the safety gate | Riskrunner's messages change |
| bowtie/loader.py | The loading and updating steps, in order | The order of steps changes |
| bowtie/compare.py | Finds what changed between two import files | A new kind of change is wanted |

## Status

Step 1 has been run on the sample workbook and on seven altered copies of it
(renamed sheets, renamed columns, missing tabs, missing columns, a blank
workbook). It has NOT been run on a second real project's hazard log.

Step 2 (routes B and C) has been rehearsed against a pretend Riskrunner only.
It has NOT yet been run against the real one, so expect the first real run to
need adjustments. Start with `--only` on one bowtie. Route A, importing by
hand, has not been tried either. The Postman collection has not been opened in
Postman; its guard script was tested on its own.
